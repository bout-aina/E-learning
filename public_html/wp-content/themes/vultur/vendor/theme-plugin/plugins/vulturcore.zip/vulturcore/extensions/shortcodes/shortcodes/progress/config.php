<?php if ( ! defined( 'FW' ) ):
	die( 'Forbidden' );
endif;
$cfg = array();
$cfg['page_builder'] = array(
	'title'       => esc_html__('Progress', 'vultur'),
	'description' => esc_html__('Progress Section', 'vultur'),
	'tab'         => esc_html__('Vultur Shortcode', 'vultur'),
    'icon'  =>'fa fa-pencil-square-o',  
);  