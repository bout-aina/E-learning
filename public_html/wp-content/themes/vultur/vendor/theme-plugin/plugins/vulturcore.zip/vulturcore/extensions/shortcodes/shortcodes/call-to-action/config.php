<?php if ( ! defined( 'FW' ) ):
	die( 'Forbidden' );
endif;
$cfg = array();
$cfg['page_builder'] = array(
	'title'       => esc_html__('Call To Action', 'vultur'),
	'description' => esc_html__('Call To Action', 'vultur'),
	'tab'         => esc_html__('Vultur Shortcode', 'vultur'),
    'icon'  =>'fa fa-pencil-square-o',  
);  